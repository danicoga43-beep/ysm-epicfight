package net.okitsu.ysmepicfightcompat.config;

import net.okitsu.ysmepicfightcompat.CompatMod;
import com.electronwill.nightconfig.core.Config;
import net.neoforged.neoforge.common.ModConfigSpec;
import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.NeoForgeConfigRegistry;
import net.neoforged.fml.config.ModConfig;
import net.okitsu.ysmepicfightcompat.animation.ModAnimationType;
import net.okitsu.ysmepicfightcompat.network.EntityModelPolicy;
import net.okitsu.ysmepicfightcompat.network.HeldItemModelPolicy;
import net.okitsu.ysmepicfightcompat.network.ModAnimationPolicy;
import net.okitsu.ysmepicfightcompat.network.MovementAnimationPolicy;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/** Client-owned cache, rendering and animation preferences, and notification state. */
public final class ClientPreferences {
    public static final int MIN_ANIMATION_EVALUATION_RATE_HZ = 30;
    public static final int MAX_ANIMATION_EVALUATION_RATE_HZ = 240;
    public static final String CONFIG_FILE =
            "ysm_epicfight_compat/ysm_epicfight_compat-client.toml";
    public static final ModConfigSpec CLIENT_SPEC;
    public static final ModConfigSpec.ConfigValue<Integer>
            CLIENT_MODEL_MEMORY_CACHE_TARGET_COUNT;
    public static final ModConfigSpec.ConfigValue<Integer>
            CLIENT_MODEL_DISK_CACHE_MIB;
    public static final ModConfigSpec.ConfigValue<Integer>
            REMOTE_MODEL_DISK_CACHE_MIB;
    public static final ModConfigSpec.BooleanValue SUPPRESS_BATTLE_MODE_OVERLAY;
    public static final ModConfigSpec.ConfigValue<Integer>
            ANIMATION_EVALUATION_RATE_LIMIT_HZ;
    public static final ModConfigSpec.BooleanValue USE_YSM_HELD_ITEM_MODELS;
    public static final ModConfigSpec.ConfigValue<Config>
            HELD_ITEM_MODEL_EXCLUSIONS;
    public static final ModConfigSpec.BooleanValue USE_YSM_PROJECTILE_MODELS;
    public static final ModConfigSpec.ConfigValue<Config>
            PROJECTILE_MODEL_EXCLUSIONS;
    public static final ModConfigSpec.BooleanValue USE_YSM_VEHICLE_MODELS;
    public static final ModConfigSpec.ConfigValue<Config>
            VEHICLE_MODEL_EXCLUSIONS;
    public static final ModConfigSpec.BooleanValue
            USE_YSM_HELD_ITEM_SWITCH_ANIMATIONS;
    public static final ModConfigSpec.ConfigValue<Config>
            HELD_ITEM_SWITCH_ANIMATION_EXCLUSIONS;
    public static final ModConfigSpec.BooleanValue
            USE_YSM_MOVEMENT_ANIMATIONS;
    public static final ModConfigSpec.BooleanValue
            USE_NATURAL_LADDER_ANIMATIONS;
    public static final ModConfigSpec.ConfigValue<Config>
            MOVEMENT_ANIMATION_EXCLUSIONS;
    public static final ModConfigSpec.ConfigValue<Boolean>
            USE_YSM_PARCOOL_ANIMATIONS;
    public static final ModConfigSpec.ConfigValue<Config>
            PARCOOL_ANIMATION_EXCLUSIONS;
    public static final ModConfigSpec.ConfigValue<Boolean>
            USE_YSM_SWEM_ANIMATIONS;
    public static final ModConfigSpec.ConfigValue<Config>
            SWEM_ANIMATION_EXCLUSIONS;
    public static final ModConfigSpec.BooleanValue YSM_WARNING_ACKNOWLEDGED;

    private static final DecodedRuleCache HELD_ITEM_MODEL_RULES =
            new DecodedRuleCache(HeldItemModelPolicy::decodeConfiguration,
                    HeldItemModelPolicy.MAX_MODELS, HeldItemModelPolicy.MAX_SELECTORS_PER_MODEL);
    private static final DecodedRuleCache PROJECTILE_MODEL_RULES =
            new DecodedRuleCache(EntityModelPolicy::decodeConfiguration,
                    EntityModelPolicy.MAX_MODELS, EntityModelPolicy.MAX_SELECTORS_PER_MODEL);
    private static final DecodedRuleCache VEHICLE_MODEL_RULES =
            new DecodedRuleCache(EntityModelPolicy::decodeConfiguration,
                    EntityModelPolicy.MAX_MODELS, EntityModelPolicy.MAX_SELECTORS_PER_MODEL);
    private static final DecodedRuleCache HELD_ITEM_SWITCH_ANIMATION_RULES =
            new DecodedRuleCache(HeldItemModelPolicy::decodeConfiguration,
                    HeldItemModelPolicy.MAX_MODELS, HeldItemModelPolicy.MAX_SELECTORS_PER_MODEL);
    private static final DecodedRuleCache MOVEMENT_ANIMATION_RULES =
            new DecodedRuleCache(MovementAnimationPolicy::decodeConfiguration,
                    MovementAnimationPolicy.MAX_MODELS, MovementAnimationPolicy.MAX_SELECTORS_PER_MODEL);
    private static final DecodedRuleCache PARCOOL_ANIMATION_RULES =
            new DecodedRuleCache(value -> ModAnimationPolicy.decodeConfiguration(ModAnimationType.PARCOOL, value),
                    ModAnimationPolicy.MAX_MODELS, ModAnimationPolicy.maxSelectorsPerModel(ModAnimationType.PARCOOL));
    private static final DecodedRuleCache SWEM_ANIMATION_RULES =
            new DecodedRuleCache(value -> ModAnimationPolicy.decodeConfiguration(ModAnimationType.SWEM, value),
                    ModAnimationPolicy.MAX_MODELS, ModAnimationPolicy.maxSelectorsPerModel(ModAnimationType.SWEM));

    static {
        ModConfigSpec.Builder config = new ModConfigSpec.Builder();
        boolean parCoolAvailable = isOptionalAnimationAvailable(ModAnimationType.PARCOOL);
        boolean swemAvailable = isOptionalAnimationAvailable(ModAnimationType.SWEM);
        config.comment("Client preferences.")
                .translation("config.ysm_epicfight_compat.client")
                .push("client");
        SUPPRESS_BATTLE_MODE_OVERLAY = config
                .comment("Suppress official YSM's extra player overlay while Epic Fight battle mode is active.",
                        "Set this to false to let official YSM render the overlay again.",
                        "The value is read for every overlay frame, so a live client-config reload takes effect without restarting.",
                        "Default: true")
                .translation("config.ysm_epicfight_compat.suppress_battle_overlay")
                .define("suppressBattleModeOverlay", true);
        ANIMATION_EVALUATION_RATE_LIMIT_HZ = config
                .comment("Target maximum YSM model animation, script, and controller evaluations per second while inputs remain reusable.",
                        "60 targets 60 updates per second. State-changing inputs may require an earlier evaluation.",
                        "Lower values make model updates less smooth; this is not a game-tick or rendering-FPS cap.",
                        "Set to zero to disable this added rate limit and restore the original evaluation cadence, including existing remote-player LOD.",
                        "Animation time and playback speed remain unchanged. Live client-config changes take effect without restarting.",
                        "Range: 0 (unlimited), 30 ~ 240",
                        "Default: 60")
                .translation("config.ysm_epicfight_compat.animation_evaluation_rate_limit_hz")
                .define("animationEvaluationRateLimitHz", 60,
                        value -> Integer.valueOf(0).equals(value)
                                || integerInRange(value, MIN_ANIMATION_EVALUATION_RATE_HZ,
                                MAX_ANIMATION_EVALUATION_RATE_HZ));
        YSM_WARNING_ACKNOWLEDGED = config
                .comment("Whether the official YSM/Epic Fight compatibility warning was already shown.",
                        "Default: false")
                .translation("config.ysm_epicfight_compat.warning_acknowledged")
                .define("epicFightCompatibilityWarningShown", false);

        config.comment("Client model memory retention target and disk cache limits.")
                .translation("config.ysm_epicfight_compat.client.cache")
                .push("cache");
        CLIENT_MODEL_MEMORY_CACHE_TARGET_COUNT = config
                .comment("Target number of converted YSM combat models retained in memory.",
                        "Only unused models are evicted. Models selected by loaded entities or needed",
                        "by pending queries are protected, so their count may exceed this target.",
                        "Range: 8 ~ 512",
                        "Default: 64")
                .translation("config.ysm_epicfight_compat.client_model_memory_cache_target_count")
                .define("clientModelMemoryCacheTargetCount", 64,
                        value -> integerInRange(value, 8, 512));
        CLIENT_MODEL_DISK_CACHE_MIB = config
                .comment("Maximum disk space in MiB for parsed models available on this client.",
                        "Set to zero to disable and clear this disk cache.",
                        "Range: 0 ~ 4096",
                        "Default: 64")
                .translation("config.ysm_epicfight_compat.client_model_disk_cache_mib")
                .define("clientModelDiskCacheMiB", 64,
                        value -> integerInRange(value, 0, 4096));
        REMOTE_MODEL_DISK_CACHE_MIB = config
                .comment("Maximum disk space in MiB for models received from multiplayer servers.",
                        "Set to zero to disable and clear this disk cache.",
                        "Range: 0 ~ 4096",
                        "Default: 64")
                .translation("config.ysm_epicfight_compat.remote_model_disk_cache_mib")
                .define("remoteModelDiskCacheMiB", 64,
                        value -> integerInRange(value, 0, 4096));
        config.pop();
        config.pop();

        // This table stays in the client config; it is not a separate Forge COMMON config.
        config.comment("Model and animation preferences stored in this client config.")
                .translation("config.ysm_epicfight_compat.common")
                .push("common");
        config.comment("YSM held-item, projectile, and vehicle model settings.")
                .translation("config.ysm_epicfight_compat.common.models")
                .push("models");
        USE_YSM_HELD_ITEM_MODELS = config
                .comment("Use model-authored YSM held-item models when available.",
                        "Only the resolved per-hand display state is synchronized; these rules remain local.",
                        "Default: true")
                .translation("config.ysm_epicfight_compat.use_ysm_held_item_models")
                .define("useYsmHeldItemModels", true);
        USE_YSM_PROJECTILE_MODELS = config
                .comment("Use model-authored YSM projectile models when no corresponding YSM held-item model controls the projectile.",
                        "Only the resolved projectile display state is synchronized; these rules remain local.",
                        "Default: true")
                .translation("config.ysm_epicfight_compat.use_ysm_projectile_models")
                .define("useYsmProjectileModels", true);
        USE_YSM_VEHICLE_MODELS = config
                .comment("Use model-authored YSM vehicle models when available.",
                        "Only the resolved vehicle display state is synchronized; these rules remain local.",
                        "Default: true")
                .translation("config.ysm_epicfight_compat.use_ysm_vehicle_models")
                .define("useYsmVehicleModels", true);

        config.comment("Model-specific exclusions for YSM model replacements.")
                .translation("config.ysm_epicfight_compat.common.models.exclusions")
                .push("exclusions");
        HELD_ITEM_MODEL_EXCLUSIONS = config
                .comment("Model-specific item IDs or #item_tags that disable YSM held-item models.",
                        "The list never enables YSM held-item models when the main setting is disabled.",
                        "Rule contents remain local; only resolved per-hand display state is synchronized.",
                        "Example: \"wine_fox/21_saint\" = [\"minecraft:diamond_sword\", \"#forge:tools/bows\"].",
                        "Default: {}")
                .translation("config.ysm_epicfight_compat.held_item_model_exclusions")
                .define("heldItemModelExclusions", Config::inMemory,
                        HeldItemModelPolicy::isValidConfiguration);
        PROJECTILE_MODEL_EXCLUSIONS = config
                .comment("Model-specific entity IDs or #entity_type_tags that disable YSM projectile models.",
                        "The list never enables YSM projectile models when the main setting is disabled.",
                        "Rule contents remain local; only the resolved projectile display state is synchronized.",
                        "Example: \"wine_fox/22_elf\" = [\"minecraft:arrow\", \"#minecraft:arrows\"].",
                        "Default: {}")
                .translation("config.ysm_epicfight_compat.projectile_model_exclusions")
                .define("projectileModelExclusions", Config::inMemory,
                        EntityModelPolicy::isValidConfiguration);
        VEHICLE_MODEL_EXCLUSIONS = config
                .comment("Model-specific entity IDs or #entity_type_tags that disable YSM vehicle models.",
                        "The list never enables YSM vehicle models when the main setting is disabled.",
                        "Rule contents remain local; only the resolved vehicle display state is synchronized.",
                        "Example: \"wine_fox/01_taisho_maid\" = [\"minecraft:boat\", \"#minecraft:boats\"].",
                        "Default: {}")
                .translation("config.ysm_epicfight_compat.vehicle_model_exclusions")
                .define("vehicleModelExclusions", Config::inMemory,
                        EntityModelPolicy::isValidConfiguration);
        config.pop();
        config.pop();

        config.comment("YSM animation preferences.")
                .translation("config.ysm_epicfight_compat.common.animations")
                .push("animations");
        USE_YSM_HELD_ITEM_SWITCH_ANIMATIONS = config
                .comment("Use official YSM held-item switch animations when the current item is not replaced by model-authored geometry.",
                        "A model-authored replacement continues to follow useYsmHeldItemModels and heldItemModelExclusions.",
                        "Only the resolved per-hand animation state is synchronized; these rules remain local.",
                        "Default: true")
                .translation("config.ysm_epicfight_compat.use_ysm_held_item_switch_animations")
                .define("useYsmHeldItemSwitchAnimations", true);
        USE_YSM_MOVEMENT_ANIMATIONS = config
                .comment("Use full-body YSM movement animations.",
                        "Only the current resolved movement state is synchronized; these rules remain local.",
                        "Default: true")
                .translation("config.ysm_epicfight_compat.use_ysm_movement_animations")
                .define("useYsmMovementAnimations", true);
        USE_NATURAL_LADDER_ANIMATIONS = config
                .comment("Use a natural two-handed ladder pose when the selected YSM ladder animation authors arm motion.",
                        "The authored pose is kept on both arms. Ordinary Epic Fight items are stowed, while items replaced by a YSM model are hidden. Models without dedicated ladder arm motion keep their original behavior.",
                        "Only the resolved pose state is synchronized; this setting remains local.",
                        "Default: true")
                .translation("config.ysm_epicfight_compat.use_natural_ladder_animations")
                .define("useNaturalLadderAnimations", true);
        USE_YSM_PARCOOL_ANIMATIONS = OptionalModConfig.defineBoolean(
                config.translation("config.ysm_epicfight_compat.use_ysm_parcool_animations"),
                "useYsmParCoolAnimations", parCoolAvailable,
                "Prioritize YSM ParCool action animations while Epic Fight battle mode is active.",
                "Epic ParCool's Chain movement and Wall movement animations always keep the addon pose when it is loaded.",
                "Actual Epic Fight attacks, guarding, and hit reactions retain Epic Fight's pose.",
                "Use parcoolAnimationExclusions to disable individual actions for each model.",
                "Independent of useYsmMovementAnimations and movementAnimationExclusions.",
                "Only the active animation identifier and its resolved pose decision are synchronized; these rules remain local.",
                "Default: true");
        USE_YSM_SWEM_ANIMATIONS = OptionalModConfig.defineBoolean(
                config.translation("config.ysm_epicfight_compat.use_ysm_swem_animations"),
                "useYsmSwemAnimations", swemAvailable,
                "Prioritize YSM SWEM riding animations while Epic Fight battle mode is active.",
                "Actual Epic Fight attacks, guarding, and hit reactions retain Epic Fight's pose.",
                "Use swemAnimationExclusions to disable individual riding animations for each model.",
                "Independent of useYsmMovementAnimations and movementAnimationExclusions.",
                "Only the active animation identifier and its resolved pose decision are synchronized; these rules remain local.",
                "Default: true");

        config.comment("Model-specific exclusions for YSM animations.")
                .translation("config.ysm_epicfight_compat.common.animations.exclusions")
                .push("exclusions");
        HELD_ITEM_SWITCH_ANIMATION_EXCLUSIONS = config
                .comment("Model-specific item IDs or #item_tags that disable YSM held-item switch animations.",
                        "These rules apply only when Epic Fight keeps rendering the ordinary item.",
                        "The list never enables YSM switch animations when the main setting is disabled.",
                        "Use minecraft:air to target the animation that switches to an empty hand.",
                        "Only the resolved per-hand animation state is synchronized; these rules remain local.",
                        "Example: \"wine_fox/05_magical\" = [\"minecraft:diamond_pickaxe\", \"minecraft:air\", \"#forge:tools/pickaxes\"].",
                        "Default: {}")
                .translation("config.ysm_epicfight_compat.held_item_switch_animation_exclusions")
                .define("heldItemSwitchAnimationExclusions", Config::inMemory,
                        HeldItemModelPolicy::isValidConfiguration);
        MOVEMENT_ANIMATION_EXCLUSIONS = config
                .comment("Model-specific movement states that disable YSM movement animations.",
                        "The list never enables YSM movement animations when the main setting is disabled.",
                        "Rule contents remain local; only the current resolved pose decision is synchronized.",
                        "Example: \"wine_fox/21_saint\" = [\"run\", \"creative_flight\"].",
                        "Default: {}")
                .translation("config.ysm_epicfight_compat.movement_animation_exclusions")
                .define("movementAnimationExclusions", Config::inMemory,
                        MovementAnimationPolicy::isValidConfiguration);
        PARCOOL_ANIMATION_EXCLUSIONS = OptionalModConfig.defineExclusions(
                config.translation("config.ysm_epicfight_compat.parcool_animation_exclusions"),
                "parcoolAnimationExclusions", ModAnimationType.PARCOOL, parCoolAvailable,
                "Model-specific ParCool actions that disable YSM ParCool animations.",
                "Use short YSM animation names without the parcool: prefix.",
                "The list never enables YSM ParCool animations when useYsmParCoolAnimations is disabled.",
                "Independent of ordinary movement and SWEM exclusions; Epic ParCool's Chain movement and Wall movement retain the addon pose.",
                "Rule contents remain local; only the current animation identifier and resolved pose decision are synchronized.",
                "Example: \"wine_fox/21_saint\" = [\"fast_running\", \"hang\"].",
                "Default: {}");
        SWEM_ANIMATION_EXCLUSIONS = OptionalModConfig.defineExclusions(
                config.translation("config.ysm_epicfight_compat.swem_animation_exclusions"),
                "swemAnimationExclusions", ModAnimationType.SWEM, swemAvailable,
                "Model-specific SWEM riding states that disable YSM SWEM animations.",
                "Use short YSM animation names without the swem: prefix.",
                "The list never enables YSM SWEM animations when useYsmSwemAnimations is disabled.",
                "Independent of ordinary movement and ParCool exclusions.",
                "Rule contents remain local; only the current animation identifier and resolved pose decision are synchronized.",
                "Example: \"wine_fox/21_saint\" = [\"gallop\", \"jump_lv1\"].",
                "Default: {}");
        config.pop();
        config.pop();

        config.pop();
        CLIENT_SPEC = config.build();
    }

    private ClientPreferences() {
    }

    public static boolean isOptionalAnimationAvailable(ModAnimationType family) {
        return OptionalModConfig.isAvailable(family);
    }

    private static boolean integerInRange(Object value, int minimum, int maximum) {
        return value instanceof Integer integer
                && integer >= minimum && integer <= maximum;
    }

    public static void register() {
        NeoForgeConfigRegistry.INSTANCE.register(CompatMod.MOD_ID, ModConfig.Type.CLIENT, CLIENT_SPEC, CONFIG_FILE);
    }

    public static boolean suppressBattleModeOverlay() {
        return SUPPRESS_BATTLE_MODE_OVERLAY.get();
    }

    public static int animationEvaluationRateLimitHz() {
        return ANIMATION_EVALUATION_RATE_LIMIT_HZ.get();
    }

    public static Map<String, List<String>> heldItemModelExclusions() {
        return HELD_ITEM_MODEL_RULES.get(
                HELD_ITEM_MODEL_EXCLUSIONS.get(), CLIENT_SPEC.isLoaded());
    }

    public static void setHeldItemModelExclusions(
            Map<String, ? extends Collection<String>> rules) {
        HELD_ITEM_MODEL_EXCLUSIONS.set(
                HeldItemModelPolicy.encodeConfiguration(rules));
        HELD_ITEM_MODEL_EXCLUSIONS.clearCache();
    }

    public static Map<String, List<String>> projectileModelExclusions() {
        return PROJECTILE_MODEL_RULES.get(
                PROJECTILE_MODEL_EXCLUSIONS.get(), CLIENT_SPEC.isLoaded());
    }

    public static void setProjectileModelExclusions(
            Map<String, ? extends Collection<String>> rules) {
        PROJECTILE_MODEL_EXCLUSIONS.set(
                EntityModelPolicy.encodeConfiguration(rules));
        PROJECTILE_MODEL_EXCLUSIONS.clearCache();
    }

    public static Map<String, List<String>> vehicleModelExclusions() {
        return VEHICLE_MODEL_RULES.get(
                VEHICLE_MODEL_EXCLUSIONS.get(), CLIENT_SPEC.isLoaded());
    }

    public static void setVehicleModelExclusions(
            Map<String, ? extends Collection<String>> rules) {
        VEHICLE_MODEL_EXCLUSIONS.set(
                EntityModelPolicy.encodeConfiguration(rules));
        VEHICLE_MODEL_EXCLUSIONS.clearCache();
    }

    public static Map<String, List<String>> heldItemSwitchAnimationExclusions() {
        return HELD_ITEM_SWITCH_ANIMATION_RULES.get(
                HELD_ITEM_SWITCH_ANIMATION_EXCLUSIONS.get(), CLIENT_SPEC.isLoaded());
    }

    public static void setHeldItemSwitchAnimationExclusions(
            Map<String, ? extends Collection<String>> rules) {
        HELD_ITEM_SWITCH_ANIMATION_EXCLUSIONS.set(
                HeldItemModelPolicy.encodeConfiguration(rules));
        HELD_ITEM_SWITCH_ANIMATION_EXCLUSIONS.clearCache();
    }

    public static Map<String, List<String>> movementAnimationExclusions() {
        return MOVEMENT_ANIMATION_RULES.get(
                MOVEMENT_ANIMATION_EXCLUSIONS.get(), CLIENT_SPEC.isLoaded());
    }

    public static void setMovementAnimationExclusions(
            Map<String, ? extends Collection<String>> rules) {
        MOVEMENT_ANIMATION_EXCLUSIONS.set(
                MovementAnimationPolicy.encodeConfiguration(rules));
        MOVEMENT_ANIMATION_EXCLUSIONS.clearCache();
    }

    public static Map<String, List<String>> parCoolAnimationExclusions() {
        return PARCOOL_ANIMATION_RULES.get(
                PARCOOL_ANIMATION_EXCLUSIONS.get(), CLIENT_SPEC.isLoaded());
    }

    public static void setParCoolAnimationExclusions(
            Map<String, ? extends Collection<String>> rules) {
        PARCOOL_ANIMATION_EXCLUSIONS.set(
                ModAnimationPolicy.encodeConfiguration(ModAnimationType.PARCOOL, rules));
        PARCOOL_ANIMATION_EXCLUSIONS.clearCache();
    }

    public static Map<String, List<String>> swemAnimationExclusions() {
        return SWEM_ANIMATION_RULES.get(
                SWEM_ANIMATION_EXCLUSIONS.get(), CLIENT_SPEC.isLoaded());
    }

    public static void setSwemAnimationExclusions(
            Map<String, ? extends Collection<String>> rules) {
        SWEM_ANIMATION_EXCLUSIONS.set(
                ModAnimationPolicy.encodeConfiguration(ModAnimationType.SWEM, rules));
        SWEM_ANIMATION_EXCLUSIONS.clearCache();
    }
}
